Britney Krogstie Project for Saving Superstore

	This is a data visualization of the profits, advertising and returns for Superstore. Below I have listed a link to each of the categories dashboard to show the visualizations. 

Profits
https://public.tableau.com/app/profile/britney.krogstie/viz/Sprint4project-Profits_17369671866010/Profits?publish=yes

	These visualizations show that the two highest profit centers are the West region selling copiers and the East region selling chairs. The two that are the biggest loss makers are binders in Central and tables in the East. The products the store should stop selling are tables, bookcases and supplies. They should focus on selling more copiers, phones and accessories. 

Advertising
https://public.tableau.com/app/profile/britney.krogstie/viz/Sprint4project-Advertising_17369672701980/Advertising?publish=yes

	The best states and months to advertise in are Indiana in October, Rhode Island in December and Vermont in November. The advertising amount in Indiana in October should be $1,800.82, in Rhode Island in December should be $599.97 and in Vermont in November it should be $238.39.

Returns
https://public.tableau.com/app/profile/britney.krogstie/viz/Sprint4project-Returns/Returns?publish=yes

	Included in the visualizations are the top 10 most returned products and the top 10 customers who make those returns. They also show that the rate of return is fairly high amongst most of the subcategories except for copiers. The company should stop selling Binders and Paper based on this analysis and focus more on copiers. 

	