https://public.tableau.com/app/profile/britney.krogstie/viz/Sprint5BritneyKrogstie/Returnratepercustomer#1


